1-> set your mongodb uri in .env file at DATABASE_URL= .
2-> open your terminal in root folder type "npm install". make sure that node.js in installed in your computer.
2-> open your terminal in root folder type "npm run dev". it will start your server on port 5000
3->open your terminal in root folder type "npm start". it will start your frontend react server on port 2000.
