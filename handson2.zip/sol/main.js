const ck = document.getElementById("slider-nav");
const dk = document.getElementById("jk");

ck.onclick = function () {
  console.log("slifer nav is working");
  dk.checked = false;
};
