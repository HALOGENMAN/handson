#steps

1--> first go to "backend" folder
2---> open Terminal in that folder
3---> run command "node server.js" in terminal
4---> then Open index.html
